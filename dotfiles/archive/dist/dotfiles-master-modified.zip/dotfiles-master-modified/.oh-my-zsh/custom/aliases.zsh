# --------------------------------- ALIASES -----------------------------------
# color
alias ls='ls --color=auto'
alias grep='grep --color=auto'
alias fgrep='fgrep --color=auto'
alias egrep='egrep --color=auto'
alias diff='diff --color=auto'
alias ip='ip --color=auto'
alias pacman='pacman --color=auto'
# other
#alias ..='cd ..'
alias scss='scss --no-cache --quiet --sourcemap=none'
alias xclip='xclip -selection c'
# replace commands
command -v vim > /dev/null && alias vi='vim'
  # ls & tree
alias ll='ls -l'
alias la='ls -A'
alias l='ls -F'
command -v lsd > /dev/null && alias ls='lsd --group-dirs first' && alias tree='lsd --tree'
command -v colorls > /dev/null && alias ls='colorls --sd --gs' && alias tree='colorls --tree'
  # cat & less
command -v bat > /dev/null && alias bat='bat --theme=ansi-$([ "$COLOR_SCHEME" = "dark" ])' && alias cat='bat --pager=never' && alias less='bat'
  # top
command -v htop > /dev/null && alias top='htop'
command -v ytop > /dev/null && alias top='ytop -p $([ "$COLOR_SCHEME" = "dark" ])'
command -v bashtop > /dev/null && alias top='bashtop' # themes for light/dark color-schemes inside ~/.config/bashtop; Press ESC to open the menu and change the theme
