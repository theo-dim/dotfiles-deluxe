#                 ██
#                ░██
#  ██████  ██████░██
# ░░░░██  ██░░░░ ░██████
#    ██  ░░█████ ░██░░░██
#   ██    ░░░░░██░██  ░██
#  ██████ ██████ ░██  ░██
# ░░░░░░ ░░░░░░  ░░   ░░
#
#  ▓▓▓▓▓▓▓▓▓▓
# ░▓ author ▓ Theodosios Dimitrasopoulos Novak | theonovak@mailfence.com
# ░▓ info   ▓ https://linktr.ee/theo_dmtr
# ░▓ repo   ▓ https://keybase.pub/theo_dmtr/
# ░▓▓▓▓▓▓▓▓▓▓
# ░░░░░░░░░░

#█▓▒░ Enable Powerlevel10k instant prompt. Should stay close to the top of ~/.zshrc.
if [[ -r "${XDG_CACHE_HOME:-$HOME/.cache}/p10k-instant-prompt-${(%):-%n}.zsh" ]]; then
  source "${XDG_CACHE_HOME:-$HOME/.cache}/p10k-instant-prompt-${(%):-%n}.zsh"
fi

#█▓▒░ Path to oh-my-zsh configuration.
export ZSH=$HOME/.oh-my-zsh

#█▓▒░ Configure ZSH Theme
ZSH_THEME="powerlevel10k/powerlevel10k"

#█▓▒░ Standard > $ZSH/plugins/ and Custom > $ZSH_CUSTOM/plugins/
plugins=(git zsh-autosuggestions zsh-syntax-highlighting)

#█▓▒░ pick a random number
#_RAND=`shuf -i1-2 -n1`

#█▓▒░ display a random ascii banner
#case $_RAND in
#1)
clear
figlet -f ~/.local/share/fonts/3d.flf "Theo Arch" | lolcat
cat << X0
theonovak.com | keybase.io/theo_dmtr | https://linktr.ee/theo_dmtr | +1 (609) 933-2990
X0
#;;
#2)
#clear
#figlet -f ~/.local/share/fonts/3d.flf "Theo Arch" | lolcat
#cat << X0
#theonovak.com | keybase.io/theo_dmtr | https://linktr.ee/theo_dmtr | +1 (609) 933-2990
#X0
#;;
#esac

#█▓▒░ Source $ZSH Extras:
source $ZSH/oh-my-zsh.sh
