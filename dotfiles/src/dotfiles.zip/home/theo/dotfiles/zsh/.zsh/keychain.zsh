#                 ██
#                ░██
#  ██████  ██████░██
# ░░░░██  ██░░░░ ░██████
#    ██  ░░█████ ░██░░░██
#   ██    ░░░░░██░██  ░██
#  ██████ ██████ ░██  ░██
# ░░░░░░ ░░░░░░  ░░   ░░
#
#  ▓▓▓▓▓▓▓▓▓▓
# ░▓ author ▓ Theodosios Dimitrasopoulos Novak | theonovak@mailfence.com
# ░▓ info   ▓ https://linktr.ee/theo_dmtr
# ░▓ repo   ▓ https://github.com/theo-dim/dotfiles-deluxe
# ░▓▓▓▓▓▓▓▓▓▓
# ░░░░░░░░░░
#
#█▓▒░ ssh keys
export SSH_KEY_PATH="~/.ssh/id_rsa"

#█▓▒░ funtoo keychain
eval `keychain -q --agents ssh,gpg --eval ~/.ssh/id_rsa`

#█▓▒░ gpg agent
GPG_TTY=$(tty)
export GPG_TTY
