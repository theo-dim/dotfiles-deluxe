
class Example
    def initialize
        @text = 'for text'
        @text2 = 'end text2'
        @text3 = '( text )'
    end
end

